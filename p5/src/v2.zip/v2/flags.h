// this file is built for p5 to share something btw diff files

int kinit2ed = 0;